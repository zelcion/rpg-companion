# rpg-calculator

Companion para o RPG

## Building and running on localhost

First install dependencies:

```sh
npm install
```

To run in hot module reloading mode:

```sh
npm start
```

## Running

Open the file `dist/index.html` in your browser
